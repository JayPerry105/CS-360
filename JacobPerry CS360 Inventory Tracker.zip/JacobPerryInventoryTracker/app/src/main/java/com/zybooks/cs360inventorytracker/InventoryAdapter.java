package com.zybooks.cs360inventorytracker;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.util.Log;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private static final String TAG = "InventoryAdapter";
    private Context context;
    private ArrayList<InventoryItem> inventoryList;
    private OnItemDeleteListener deleteListener;
    private DatabaseHelper dbHelper;
    private OnQuantityZeroListener quantityZeroListener;

    public interface OnItemDeleteListener {
        void onDeleteItem(int itemId, int position);
    }

    public interface OnQuantityZeroListener {
        void onQuantityZero(InventoryItem item);
    }

    public InventoryAdapter(Context context, ArrayList<InventoryItem> inventoryList, OnItemDeleteListener deleteListener, OnQuantityZeroListener quantityZeroListener) {
        this.context = context;
        this.inventoryList = inventoryList;
        this.deleteListener = deleteListener;
        this.dbHelper = new DatabaseHelper(context);
        this.quantityZeroListener = quantityZeroListener;
        Log.e("InventoryAdapter", "Listener assigned: " + (deleteListener != null));
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_view_item, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, @SuppressLint("RecyclerView") int position) {
        InventoryItem item = inventoryList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (deleteListener != null) {
                    deleteListener.onDeleteItem(item.getId(), position); // Ensuring deleteListener is not null
                } else {
                    Log.e("InventoryAdapter", "Delete listener is null");
                }
            }
        });

        holder.incrementButton.setOnClickListener(v -> {
            incrementQuantity(item, holder.itemQuantity);
        });

        holder.decrementButton.setOnClickListener(v -> {
            decrementQuantity(item, holder.itemQuantity);
        });
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    private void incrementQuantity(InventoryItem item, TextView itemQuantityView) {
        int newQuantity = item.getQuantity() + 1;
        updateQuantity(item.getId(), newQuantity);
        item.setQuantity(newQuantity);
        itemQuantityView.setText(String.valueOf(newQuantity));
    }

    private void decrementQuantity(InventoryItem item, TextView itemQuantityView) {
        int newQuantity = item.getQuantity() - 1;
        if (newQuantity >= 0) {
            updateQuantity(item.getId(), newQuantity);
            item.setQuantity(newQuantity);
            itemQuantityView.setText(String.valueOf(newQuantity));
            if (newQuantity == 0) {
                if (quantityZeroListener != null) {
                    Log.d(TAG, "Item quantity is zero: " + item.getName());
                    quantityZeroListener.onQuantityZero(item);
                }
            }
        }
    }

    private void updateQuantity(int itemId, int newQuantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, newQuantity);
        db.update(DatabaseHelper.TABLE_INVENTORY, values, DatabaseHelper.COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
    }


    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQuantity;
        ImageButton deleteButton, incrementButton, decrementButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            incrementButton = itemView.findViewById(R.id.incrementButton);
            decrementButton = itemView.findViewById(R.id.decrementButton);
        }
    }
}
