package com.zybooks.cs360inventorytracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class GridActivity extends AppCompatActivity implements InventoryAdapter.OnItemDeleteListener, InventoryAdapter.OnQuantityZeroListener {

    private RecyclerView recyclerView;
    private InventoryAdapter inventoryAdapter;
    private DatabaseHelper dbHelper;
    private ArrayList<InventoryItem> inventoryList;
    private static final int SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        // Log to confirm that onCreate is called
        Log.d("GridActivity", "onCreate called");

        recyclerView = findViewById(R.id.gridView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 4));

        dbHelper = new DatabaseHelper(this);
        inventoryList = loadInventory();

        inventoryAdapter = new InventoryAdapter(this, inventoryList, this, this);
        recyclerView.setAdapter(inventoryAdapter);

        // Log to confirm onCreate() execution
        Log.e("GridActivity", "onCreate executed, Adapter initialized.");

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialogToAddItem();
            }
        });

        ImageButton settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(GridActivity.this, SMSActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onDeleteItem(int itemId, int position) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int deletedRows = db.delete(DatabaseHelper.TABLE_INVENTORY, DatabaseHelper.COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        if (deletedRows > 0) {
            inventoryList.remove(position);
            inventoryAdapter.notifyItemRemoved(position);
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
        }
    }

    private ArrayList<InventoryItem> loadInventory() {
        ArrayList<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_INVENTORY, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_NAME));
                @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_QUANTITY));
                items.add(new InventoryItem(id, name, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    @Override
    public void onQuantityZero(InventoryItem item) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSmsNotification(item);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    private void sendSmsNotification(InventoryItem item) {
        SmsManager smsManager = SmsManager.getDefault();
        String message = "Item: " + item.getName() + " is out of stock!";
        smsManager.sendTextMessage("1234567890", null, message, null, null);
        Toast.makeText(this, "SMS Sent: " + message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                for (InventoryItem item : inventoryList) {
                    if (item.getQuantity() == 0) {
                        sendSmsNotification(item);
                    }
                }
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showDialogToAddItem() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_add_item);

        final EditText editTextName = dialog.findViewById(R.id.editTextItemName);
        final EditText editTextQuantity = dialog.findViewById(R.id.editTextItemQuantity);
        Button buttonAdd = dialog.findViewById(R.id.buttonAddItem);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                int quantity = Integer.parseInt(editTextQuantity.getText().toString());
                addItemToDatabase(name, quantity);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void addItemToDatabase(String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, name);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, quantity);

        long result = db.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
        if (result == -1) {
            Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
        } else {
            inventoryList.add(new InventoryItem((int) result, name, quantity));
            inventoryAdapter.notifyItemInserted(inventoryList.size() - 1);
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
